# TARA

TARA is a cross-platform messaging app concept for Android and iOS.

## Stack
- Flutter
- Firebase (to be connected)
- GitHub

## Current foundation
- TARA branding
- T+R logo concept
- Splash screen
- Phone login screen
- OTP screen
- Profile setup screen
- Chat list screen
- Basic chat screen

## Next step
Connect Firebase Authentication and Cloud Firestore.
