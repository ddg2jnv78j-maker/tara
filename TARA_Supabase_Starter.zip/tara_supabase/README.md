# TARA — Supabase Starter

Flutter + Supabase starter for TARA.

Includes:
- TARA splash screen
- Phone login UI
- OTP UI
- Chat list
- Basic chat UI
- Supabase Flutter dependency
- No secret keys included

Next: connect Supabase Auth, Database, Realtime and Storage.
Never put a Supabase service-role key in a mobile app.
